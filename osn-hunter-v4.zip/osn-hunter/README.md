# OSN Hunter System v4

Sistem belajar Competitive Programming bergaya RPG untuk OSN Informatika.

## Cara Deploy ke GitHub Pages (akses dari HP & Laptop)

### Langkah 1 — Buat repo GitHub
1. Buka [github.com](https://github.com) → login atau daftar gratis
2. Klik **New repository**
3. Nama repo: `osn-hunter` (atau bebas)
4. Pilih **Public**
5. Klik **Create repository**

### Langkah 2 — Upload file
Di halaman repo yang baru dibuat:
1. Klik **uploading an existing file**
2. Drag & drop seluruh isi folder `osn-hunter/` ini (semua file dan folder)
3. Klik **Commit changes**

Pastikan struktur di GitHub seperti ini:
```
osn-hunter/
├── index.html          ← file utama
├── css/style.css
├── js/app.js
├── js/cf.js
├── js/tlx.js
├── js/atcoder.js
├── js/ui.js
├── js/notes.js
├── js/guide.js
└── data/
    ├── topics.json
    └── tlx.json
```

### Langkah 3 — Aktifkan GitHub Pages
1. Di repo → klik tab **Settings**
2. Sidebar kiri → klik **Pages**
3. Source: pilih **Deploy from a branch**
4. Branch: pilih **main**, folder: **/ (root)**
5. Klik **Save**
6. Tunggu 1–2 menit

### Langkah 4 — Akses
URL kamu akan jadi: `https://USERNAME.github.io/osn-hunter/`

Buka URL itu dari HP atau laptop mana pun!

---

## Catatan Penting

**Data tersimpan di localStorage browser** — artinya data HP dan laptop terpisah.
Untuk sinkronisasi antar perangkat, gunakan fitur **Export/Import JSON** di tab Pengaturan:
- Di HP: Export → simpan file ke Google Drive / WhatsApp ke diri sendiri
- Di laptop: Import file tersebut

---

## Fitur

| Tab | Fungsi |
|-----|--------|
| Status | Stat hunter + rating CF/TLX/AtCoder + tambah stat custom |
| CF Sync | Sync akun CF → XP otomatis dari semua soal AC (anti-farm) |
| Grind | Random soal CF berdasarkan rating target |
| Pomodoro | Timer fokus dengan log sesi |
| Topik | 35+ topik OSN dengan unlock system + custom topic |
| Aktivitas | Streak 28 hari + kalender jadwal |
| Catatan | Catatan dengan sistem project/group |
| Guide ⚡ | Roadmap OSN-K/P/S/F + tanya Claude AI |
| Rank | Tangga rank dari Rookie → IOI Hunter |
| Reward | Tukar XP dengan reward nyata |
| TLX | Progress TLX Course + OSN/OSN-P Olympiad per soal |
| AtCoder | Tabel ABC/ARC/AGC ala KenkoOO (virtual scroll) |
| Pengaturan | Zoom, API key Claude, export/import |

---

## XP System

Formula level: `150 × 1.06^(level-1)` — naik 6% per level

| Aktivitas | XP |
|-----------|-----|
| CF AC rating 800–3500 | 15–558 XP |
| AtCoder AC (A–G) | 10–150 XP |
| TLX Olympiad AC | 40 XP |
| TLX Course sub-bab | 5 XP/soal |
| Streak harian | 20 XP |
| Pomodoro sesi | 12 XP |
| Tambah stat | 10 XP |
| Topik +5% | 8 XP |
